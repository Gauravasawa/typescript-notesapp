import './App.css';

function App() {
  const a = 10;

  const b = 5;

  return (
    <div>
      <h1>{a}</h1>
      <h1>{b}</h1>
    </div>
  );
}

export default App;
